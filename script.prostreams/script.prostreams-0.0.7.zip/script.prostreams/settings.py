#      Copyright (C) 2015 Justin Mills
#      
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmcgui, utils

addon_id = 'script.prostreams'
dlg = xbmcgui.Dialog()


def showTOS():
	tos = utils.get_setting(addon_id,'tos')== "true"
	if tos == False:
		utils.set_setting(addon_id, 'tos', 'true')
		ok = xbmcgui.Dialog().ok("Pro Streams TV Guide Members Only","Please Enter your Username and Password on the following screen.","If you have yet to obtain this information please request it by emailing prostreams@hushmail.com","Or via their facebook group called Pro Streams")

def setSettings(username,password,userid):
       username = utils.set_setting(addon_id, 'username', username)
       password = utils.set_setting(addon_id, 'password', password)
       userid = utils.set_setting(addon_id, 'userid', userid)

def setUrl():
	user = utils.set_setting(addon_id, 'userurl', 'http://37.187.249.63/xmls/sub/') 
	url = utils.set_setting(addon_id, 'mainurl', 'http://37.187.249.63/xmls/sub/')
	logos = utils.set_setting(addon_id, 'logos', 'http://37.187.249.63/xmls/sub/logos/')	
	   
def checkSettings():
        username = utils.get_setting(addon_id,'username')
        password = utils.get_setting(addon_id,'password')
        userid = utils.get_setting(addon_id,'userid')
        if not username:
                retval = dlg.input('Enter prostreams Guide Username', type=xbmcgui.INPUT_ALPHANUM)
                if retval and len(retval) > 0:
                        utils.set_setting(addon_id, 'username', str(retval))
                        username = utils.get_setting(addon_id, 'username')
        
        if not password:
                retval = dlg.input('Enter prostreams Guide Password', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if retval and len(retval) > 0:
                        utils.set_setting(addon_id, 'password', str(retval))
                        password = utils.get_setting(addon_id, 'password')
		
        if not userid:
                retval = dlg.input('Enter prostreams Guide UserID', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if retval and len(retval) > 0:
                        utils.set_setting(addon_id, 'userid', str(retval))
                        userid = utils.get_setting(addon_id, 'userid')

