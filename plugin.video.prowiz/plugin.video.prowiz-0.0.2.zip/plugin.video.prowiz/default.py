import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
from addon.common.addon import Addon
from addon.common.net import Net
###THANK YOU TO THOSE THAT MADE THE BASE OF THIS WIZARD GREAT WORK###


USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.video.prowiz'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonTitle="ProStreams Tools" 
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "0.0.1"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Prostreams Tools"            
BASEURL = "http://37.187.249.63/"
H = 'http://'

def INDEX():
    addDir('Pro HD TOOLS',BASEURL,2,ART+'tools.png',FANART,'')
    setView('movies', 'MAIN')

def CUSTOMPRO():
    addDir('INSTALL Pro HD XML Config',BASEURL+'xmls/wizard/settings.xml',17,ART+'settings.png',FANART,'')
    addDir('RESET ProStreams DATABASE','url',18,ART+'reset.jpg',FANART,'')
    addDir('INSTALL Kodi 16 PVR STALKER Config',BASEURL+'xmls/wizard/pvrstalk/kodi16/settings.xml',19,ART+'PVR16.png',FANART,'')
    addDir('INSTALL Kodi 15 PVR STALKER Config',BASEURL+'xmls/wizard/pvrstalk/kodi15/settings.xml',20,ART+'PVR15.png',FANART,'')
    setView('movies', 'MAIN')
	
def CUSTOMSET(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Pro HD XML TYPE", '                               Install Settings File'):
        print '###'+AddonTitle+' - CUSTOM Pro HD SETTINGS###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.prostreams',''))
        advance=os.path.join(path, 'settings.xml')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== Pro HD XML TYPE - WRITING    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding XML Settings")  
    return
	
	
def CUSTOMPVR(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Kodi 16 PVR.STALKER Settings", '        Install default Kodi 16 PVR.STALKER Settings File'):
        print '###'+AddonTitle+' - Kodi 16 PVR.STALKER Settings###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/pvr.stalker',''))
        advance=os.path.join(path, 'settings.xml')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== ProStreams PVR.STALKER - WRITING new config    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding PVR Settings please configure the pvr addon next replacing the XX with your details")  
    return
	
def CUSTOMPVR15(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Kodi 15.2 PVR.STALKER Settings", '        Install default Kodi 15.2 PVR.STALKER Settings File'):
        print '###'+AddonTitle+' - Kodi 15 PVR.STALKER Settings###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/pvr.stalker',''))
        advance=os.path.join(path, 'settings.xml')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== ProStreams PVR.STALKER - WRITING new config    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding PVR Settings please configure the pvr addon next replacing the XX with your details")  
    return
	
def DELETEPRODB():
    pro_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.prostreams/'), '')
    if os.path.exists(pro_cache_path)==True:    
        for root, dirs, files in os.walk(pro_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete  database Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				

    dialog = xbmcgui.Dialog()
    dialog.ok("ProStreams Reset", "       All Cache Files Removed", "          [COLOR yellow]Please try Running the Guide again[/COLOR]")

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==1:
        REPOMAINTENANCE()

elif mode==2:
        CUSTOMPRO()

elif mode==3:
        MAINTENANCE()
		
elif mode==4:
        deletecachefiles(url)
		
elif mode==5:
        WIZARD(name,url,description)

elif mode==6:
        WIZARD1(name,url,description)
		
elif mode==10:
        UPDATEREPO()
		
elif mode==17:
        CUSTOMSET(url,name)

elif mode==18:
        DELETEPRODB()
		
elif mode==19:
        CUSTOMPVR(url,name)

elif mode==20:
        CUSTOMPVR15(url,name)

elif mode==21:
        CUSTOMSET3(url,name)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
